*PADS-LIBRARY-PART-TYPES-V9*

LT8645SEV-2#WPBF LT8645SEV2WPBF I ANA 9 1 0 0 0
TIMESTAMP 2026.09.08.16.30.23
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" LT8645SEV-2#WPBF
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" 65V, 8A Synchronous Step-Down Silent Switcher with 2.5A Quiescent Current
"Datasheet Link" https://www.analog.com/LT8645S-2/datasheet
"Geometry.Height" 1.03mm
GATE 1 42 0
LT8645SEV-2#WPBF
1 0 U BIAS
2 0 U INTVCC
3 0 U NC_1
4 0 U VIN_1
5 0 U VIN_2
6 0 U VIN_3
7 0 U NC_2
8 0 U GND_1
9 0 U GND_2
10 0 U GND_3
11 0 U BST
12 0 U SW_1
13 0 U SW_2
14 0 U SW_3
15 0 U SW_4
16 0 U SW_5
17 0 U GND_4
18 0 U GND_5
19 0 U GND_6
20 0 U NC_3
21 0 U VIN_4
22 0 U VIN_5
23 0 U VIN_6
24 0 U NC_4
25 0 U EN/UV
26 0 U RT
27 0 U CLKOUT
28 0 U SYNC/MODE
29 0 U TR/SS
30 0 U GND_7
31 0 U PG
32 0 U FB
33 0 U GND_8
34 0 U GND_9
35 0 U GND_10
36 0 U GND_11
37 0 U GND_12
38 0 U GND_13
39 0 U EP_1
40 0 U EP_2
41 0 U EP_3
42 0 U EP_4

*END*
*REMARK* SamacSys ECAD Model
19948984/2125079/2.50/42/2/Integrated Circuit
